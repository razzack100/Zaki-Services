ZAKI SERVICES PRESENTATION SITE

This is a static presentation landing page.
It has:
- Mercedes G-Class, Porsche Cayenne and Audi Q8 technical breakdown slides
- Automatic slideshow
- Previous/next vehicle arrows
- Orange pointer glow
- No working shop/cart/payment buttons yet

GitHub Pages:
1. Upload all files in this folder to the repository root.
2. GitHub > Settings > Pages.
3. Under Build and deployment, choose Deploy from a branch.
4. Select main branch and / (root).
5. Save.
6. GitHub will provide the public Pages URL.

Do not add payment API keys yet.
